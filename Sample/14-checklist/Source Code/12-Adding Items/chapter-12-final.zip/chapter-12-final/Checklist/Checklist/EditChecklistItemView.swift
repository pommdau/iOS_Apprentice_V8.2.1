//
//  EditChecklistItemView.swift
//  Checklist
//
//  Created by Joey deVilla on 1/25/20.
//  Copyright © 2020 Joey deVilla. All rights reserved.
//

import SwiftUI

struct EditChecklistItemView: View {

  // Properties
  // ==========

  var body: some View {
    Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
  }
}


// Preview
// =======

struct EditChecklistItemView_Previews: PreviewProvider {
  static var previews: some View {
    EditChecklistItemView()
  }
}
